# Interactive Business Intelligence Dashboard

A beginner-friendly Streamlit dashboard for exploring revenue, active users, churn rate, and an average-ticket-size proxy. It includes date, region, and category filters plus interactive charts and CSV export.

## Files
- `app.py` — Streamlit dashboard application
- `dashboard_sample_dataset.csv` — synthetic sample data (Jan–Jun 2026)
- `requirements.txt` — Python dependencies
- `Interactive_Dashboard_Project_Report.pdf` — project report
- `Interactive_BI_Dashboard.ipynb` — notebook with data checks and summary analysis

## Run locally
1. Install Python 3.10 or later.
2. Open a terminal in this folder.
3. Install dependencies: `pip install -r requirements.txt`
4. Start the dashboard: `streamlit run app.py`
5. Open the local URL shown in the terminal (usually `http://localhost:8501`).

## Publish a public dashboard
1. Create a public GitHub repository and upload `app.py`, `requirements.txt`, `dashboard_sample_dataset.csv`, and this README.
2. Open [Streamlit Community Cloud](https://share.streamlit.io/) and sign in with GitHub.
3. Choose **Create app**, select your repository and branch, set the main file path to `app.py`, and deploy.
4. Copy the public app URL into your submission.

The public URL cannot be created from this package alone because deployment requires your own GitHub/Streamlit account authorization.

## KPI definitions
- **Total Revenue:** sum of Revenue for the selected records.
- **Active Users:** sum of Active_Users across selected records. This is a period-level aggregate and may double-count users across records.
- **Churn Rate:** total Churned_Customers divided by total Active_Users, multiplied by 100. Replace with your organization's official definition if different.
- **Avg Ticket Size (proxy):** Revenue divided by Active_Users because order counts are not included. For true average order value, include `Orders` and calculate Revenue / Orders.

## Important data note
The included dataset is synthetic, generated only to demonstrate the dashboard workflow. Results are not real-world business findings. Replace it with an approved, properly cleaned dataset before drawing business conclusions.
